import express from "express";
console.log("Starting server.ts...");
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

let db: any;
try {
  console.log("Initializing database...");
  db = new Database("physio.db");
  console.log("Database initialized.");
} catch (err) {
  console.error("Failed to initialize database file, falling back to in-memory:", err);
  try {
    db = new Database(":memory:");
    console.log("In-memory database initialized.");
  } catch (memErr) {
    console.error("Failed to initialize in-memory database:", memErr);
    process.exit(1);
  }
}

// Initialize Database
try {
  db.exec(`
  CREATE TABLE IF NOT EXISTS patients (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT,
    phone TEXT NOT NULL,
    history TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS sessions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    patient_id INTEGER,
    date_time DATETIME NOT NULL,
    type TEXT CHECK(type IN ('zoom', 'whatsapp', 'meet')) NOT NULL,
    status TEXT DEFAULT 'scheduled',
    payment_status TEXT DEFAULT 'pending',
    video_link TEXT,
    notes TEXT,
    reminder_sent INTEGER DEFAULT 0,
    FOREIGN KEY (patient_id) REFERENCES patients(id)
  );

  CREATE TABLE IF NOT EXISTS partners (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    city TEXT NOT NULL,
    experience INTEGER,
    email TEXT,
    phone TEXT,
    status TEXT DEFAULT 'pending'
  );
`);
  console.log("Database schema verified.");
} catch (err) {
  console.error("Failed to execute database schema:", err);
  process.exit(1);
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // Serve specific static files
  app.get("/input_file_1.png", (req, res) => res.sendFile(path.join(__dirname, "input_file_1.png")));
  app.get("/input_file_2.png", (req, res) => res.sendFile(path.join(__dirname, "input_file_2.png")));
  app.get("/input_file_1.jpg", (req, res) => res.sendFile(path.join(__dirname, "input_file_1.jpg")));
  app.get("/input_file_2.jpg", (req, res) => res.sendFile(path.join(__dirname, "input_file_2.jpg")));

  // API Routes
  app.get("/api/patients", (req, res) => {
    const patients = db.prepare("SELECT * FROM patients ORDER BY name ASC").all();
    res.json(patients);
  });

  app.post("/api/patients", (req, res) => {
    const { name, email, phone, history } = req.body;
    const info = db.prepare("INSERT INTO patients (name, email, phone, history) VALUES (?, ?, ?, ?)").run(name, email, phone, history);
    res.json({ id: info.lastInsertRowid });
  });

  app.get("/api/sessions", (req, res) => {
    const sessions = db.prepare(`
      SELECT s.*, p.name as patient_name 
      FROM sessions s 
      JOIN patients p ON s.patient_id = p.id 
      ORDER BY s.date_time ASC
    `).all();
    res.json(sessions);
  });

  app.post("/api/sessions", (req, res) => {
    const { patient_id, date_time, type, video_link, notes } = req.body;
    const info = db.prepare("INSERT INTO sessions (patient_id, date_time, type, video_link, notes) VALUES (?, ?, ?, ?, ?)").run(patient_id, date_time, type, video_link, notes);
    res.json({ id: info.lastInsertRowid });
  });

  app.patch("/api/sessions/:id", (req, res) => {
    const { status, payment_status } = req.body;
    db.prepare("UPDATE sessions SET status = ?, payment_status = ? WHERE id = ?").run(status, payment_status, req.params.id);
    res.json({ success: true });
  });

  app.post("/api/partners", (req, res) => {
    const { name, city, experience, email, phone } = req.body;
    const info = db.prepare("INSERT INTO partners (name, city, experience, email, phone) VALUES (?, ?, ?, ?, ?)").run(name, city, experience, email, phone);
    res.json({ id: info.lastInsertRowid });
  });

  app.get("/api/partners", (req, res) => {
    const partners = db.prepare("SELECT * FROM partners ORDER BY city ASC").all();
    res.json(partners);
  });

  app.post("/api/intake", (req, res) => {
    const { name, phone, age, condition, slots, final } = req.body;
    
    // 1. Create or update patient
    const existingPatient = db.prepare("SELECT id FROM patients WHERE phone = ?").get(phone) as { id: number } | undefined;
    let patientId: number;
    
    if (existingPatient) {
      patientId = existingPatient.id;
      db.prepare("UPDATE patients SET history = ? WHERE id = ?").run(condition, patientId);
    } else {
      const info = db.prepare("INSERT INTO patients (name, phone, history) VALUES (?, ?, ?)").run(name, phone, condition);
      patientId = info.lastInsertRowid as number;
    }

    // 2. Create requested sessions
    const insertSession = db.prepare("INSERT INTO sessions (patient_id, date_time, type, status, payment_status, notes) VALUES (?, ?, ?, ?, ?, ?)");
    
    for (const slot of slots) {
      insertSession.run(patientId, slot, 'whatsapp', 'requested', 'pending', `Bulk booking request. Total quoted: ₹${final}`);
    }

    res.json({ success: true });
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { 
        middlewareMode: true,
        hmr: { port: 24678 + Math.floor(Math.random() * 1000) }
      },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer().catch(err => {
  console.error("Critical error starting server:", err);
  process.exit(1);
});
