import React from 'react';

export const DoctorPhoto = ({ className }: { className?: string }) => {
  const [error, setError] = React.useState(false);
  const photoUrl = `${process.env.APP_URL}/input_file_1.png`;
  const fallbackUrl = "https://images.unsplash.com/photo-1612349317150-e413f6a5b16d?auto=format&fit=crop&q=80&w=800"; // Real doctor photo from Unsplash

  return (
    <img 
      src={error ? fallbackUrl : photoUrl} 
      alt="Dr. Shailendra Kumar Saxena" 
      className={className}
      referrerPolicy="no-referrer"
      onError={() => {
        if (!error) setError(true);
      }}
    />
  );
};
