import React from 'react';
import { 
  CheckCircle2, 
  Clock, 
  Video, 
  Shield, 
  ChevronRight, 
  Star, 
  ArrowRight,
  MessageCircle,
  Stethoscope,
  Activity,
  Award,
  Users,
  MapPin,
  Mail,
  Phone
} from 'lucide-react';
import { motion } from 'motion/react';

const COLORS = {
  orange: '#ff915a',
  green: '#8bc38b',
  yellow: '#fdf4aa'
};

const Navbar = () => (
  <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-slate-100">
    <div className="container mx-auto px-6 h-20 flex items-center justify-between">
      <div className="flex items-center gap-3">
        <div className="w-10 h-10 bg-brand-orange rounded-xl flex items-center justify-center text-white font-bold text-xl">P</div>
        <span className="font-display font-bold text-slate-900 text-xl">The Online Physio</span>
      </div>
      <div className="hidden md:flex items-center gap-8">
        <a href="#about" className="text-slate-600 font-semibold hover:text-brand-orange transition-colors">About</a>
        <a href="#services" className="text-slate-600 font-semibold hover:text-brand-orange transition-colors">Services</a>
        <a href="#pricing" className="text-slate-600 font-semibold hover:text-brand-orange transition-colors">Pricing</a>
        <a href="#partners" className="text-slate-600 font-semibold hover:text-brand-orange transition-colors">Partner Network</a>
        <a href="#contact" className="btn-primary">Book Now</a>
      </div>
    </div>
  </nav>
);

const Hero = () => (
  <section className="relative pt-20 pb-32 overflow-hidden">
    <div className="absolute top-0 right-0 w-1/2 h-full bg-brand-yellow/10 -skew-x-12 translate-x-1/4 -z-10" />
    <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
      <motion.div 
        initial={{ opacity: 0, x: -20 }}
        animate={{ opacity: 1, x: 0 }}
        className="space-y-8"
      >
        <div className="inline-flex items-center gap-2 px-4 py-2 bg-brand-green/10 text-brand-green rounded-full text-sm font-bold">
          <CheckCircle2 size={16} /> 19+ Years of Clinical Excellence
        </div>
        <h1 className="text-6xl md:text-7xl font-display font-black text-slate-900 leading-tight">
          Heal Better. <br />
          <span className="text-brand-orange">From Anywhere.</span>
        </h1>
        <p className="text-xl text-slate-600 max-w-lg leading-relaxed">
          Expert online physiotherapy by Dr. Shailendra Kumar Saxena (PT). India's pioneer in tele-rehabilitation, bringing recovery to your doorstep.
        </p>
        <div className="flex flex-wrap gap-4">
          <a href="#contact" className="btn-primary text-lg px-8 py-4">Start Your Recovery</a>
          <a href="#about" className="px-8 py-4 rounded-xl font-bold text-slate-600 hover:bg-slate-100 transition-all">Learn More</a>
        </div>
        <div className="flex items-center gap-8 pt-4">
          <div className="flex -space-x-4">
            {[1,2,3,4].map(i => (
              <div key={i} className="w-12 h-12 rounded-full border-4 border-white bg-slate-200 overflow-hidden">
                <img src={`https://picsum.photos/seed/${i+10}/100/100`} alt="Patient" referrerPolicy="no-referrer" />
              </div>
            ))}
          </div>
          <p className="text-sm font-semibold text-slate-500">Trusted by 500+ patients across India</p>
        </div>
      </motion.div>
      <motion.div 
        initial={{ opacity: 0, scale: 0.9 }}
        animate={{ opacity: 1, scale: 1 }}
        className="relative"
      >
        <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl border-8 border-white">
          <img 
            src="https://ais-dev-4v4zt3yy4lvdowyjkr7lsk-576095946651.asia-southeast1.run.app/input_file_1.png" 
            alt="Dr. Shailendra Kumar Saxena" 
            className="w-full h-auto"
            referrerPolicy="no-referrer"
          />
        </div>
        <div className="absolute -bottom-6 -left-6 z-20 glass-card p-6 rounded-2xl max-w-xs">
          <div className="flex items-center gap-3 mb-2">
            <Award className="text-brand-orange" />
            <span className="font-bold text-slate-900">NDTV Featured</span>
          </div>
          <p className="text-sm text-slate-500">Recognized as a pioneer in Indian tele-rehabilitation services.</p>
        </div>
      </motion.div>
    </div>
  </section>
);

const Services = () => {
  const services = [
    { title: "Back & Disc Care", icon: <Activity />, color: "bg-blue-50 text-blue-500" },
    { title: "Arthritis Management", icon: <Stethoscope />, color: "bg-green-50 text-green-500" },
    { title: "Sports Rehab", icon: <Award />, color: "bg-orange-50 text-orange-500" },
    { title: "Post-COVID Recovery", icon: <Shield />, color: "bg-purple-50 text-purple-500" },
  ];

  return (
    <section id="services" className="py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-4xl font-display font-bold text-slate-900 mb-4">Specialized Care for Every Need</h2>
          <p className="text-slate-600">Comprehensive online management for musculoskeletal and age-related conditions.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {services.map((s, i) => (
            <motion.div 
              whileHover={{ y: -5 }}
              key={i} 
              className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100"
            >
              <div className={`w-14 h-14 ${s.color} rounded-2xl flex items-center justify-center mb-6`}>
                {React.cloneElement(s.icon as React.ReactElement, { size: 28 })}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-3">{s.title}</h3>
              <p className="text-slate-500 text-sm leading-relaxed">Evidence-based protocols tailored to your specific recovery goals and lifestyle.</p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
};

const Pricing = () => {
  const plans = [
    { name: "Pre-Consult Review", price: "400", duration: "15 min", features: ["Quick medical enquiries", "Rapid progress updates", "Expert steer"], icon: <Clock /> },
    { name: "Routine Follow-Up", price: "600", duration: "30 min", features: ["Ongoing rehab supervision", "Plan adjustments", "Bonus 5 mins"], icon: <Activity /> },
    { name: "Standard Consultation", price: "800", duration: "45 min", features: ["Full first-time assessment", "Personalized roadmap", "Self-reschedule enabled"], icon: <Video />, featured: true },
    { name: "Comprehensive Review", price: "1000", duration: "60 min", features: ["Complex chronic cases", "Deep-dive analysis", "Bonus 5 mins"], icon: <Users /> },
  ];

  return (
    <section id="pricing" className="py-24">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <h2 className="text-4xl font-display font-bold text-slate-900 mb-4">Transparent Consultation Plans</h2>
          <p className="text-slate-600">Simple, affordable, and professional. Choose the session that fits your needs.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {plans.map((p, i) => (
            <div 
              key={i} 
              className={`p-8 rounded-3xl border ${p.featured ? 'border-brand-orange bg-brand-orange/5 ring-4 ring-brand-orange/10' : 'border-slate-200 bg-white'} flex flex-col`}
            >
              <div className="flex justify-between items-start mb-6">
                <div className={`p-3 rounded-xl ${p.featured ? 'bg-brand-orange text-white' : 'bg-slate-100 text-slate-500'}`}>
                  {React.cloneElement(p.icon as React.ReactElement, { size: 24 })}
                </div>
                {p.featured && <span className="bg-brand-orange text-white text-[10px] font-black px-2 py-1 rounded-full">POPULAR</span>}
              </div>
              <h3 className="text-xl font-bold text-slate-900 mb-2">{p.name}</h3>
              <div className="flex items-baseline gap-1 mb-4">
                <span className="text-3xl font-black text-slate-900">₹{p.price}</span>
                <span className="text-slate-500 text-sm">/ {p.duration}</span>
              </div>
              <ul className="space-y-3 mb-8 flex-1">
                {p.features.map((f, j) => (
                  <li key={j} className="flex items-center gap-2 text-sm text-slate-600">
                    <CheckCircle2 size={14} className="text-brand-green" /> {f}
                  </li>
                ))}
              </ul>
              <a href="#contact" className={`w-full py-3 rounded-xl font-bold text-center transition-all ${p.featured ? 'bg-brand-orange text-white shadow-lg shadow-brand-orange/20' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}>
                Book Session
              </a>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

const PartnerNetwork = () => (
  <section id="partners" className="py-24 bg-brand-green/5">
    <div className="container mx-auto px-6">
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
        <div>
          <span className="text-brand-green font-bold text-sm tracking-widest uppercase mb-4 block">Partner Network</span>
          <h2 className="text-4xl md:text-5xl font-display font-bold text-slate-900 mb-8 leading-tight">
            Join The Physical Health Consultants Partner Network
          </h2>
          <p className="text-lg text-slate-600 mb-8 leading-relaxed">
            Are you an early-career physiotherapist in a Tier 2 or Tier 3 city? Align your practice with 19 years of clinical expertise.
          </p>
          <div className="space-y-6 mb-10">
            {[
              "Direct Patient Referrals for in-clinic care",
              "Professional Recognition & Branding",
              "Clinical Mentorship & Case Consultations",
              "Zero Financial Investment Required"
            ].map((item, i) => (
              <div key={i} className="flex items-center gap-4">
                <div className="w-6 h-6 bg-brand-green rounded-full flex items-center justify-center text-white">
                  <CheckCircle2 size={14} />
                </div>
                <span className="font-semibold text-slate-700">{item}</span>
              </div>
            ))}
          </div>
          <button className="btn-secondary flex items-center gap-2">
            Apply to Join <ArrowRight size={20} />
          </button>
        </div>
        <div className="grid grid-cols-2 gap-4">
          <div className="space-y-4">
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100">
              <h4 className="font-bold text-slate-900 mb-2">Tier 2 Cities</h4>
              <p className="text-xs text-slate-500">Mysore, Coimbatore, Jaipur, Lucknow, Indore, Patna...</p>
            </div>
            <div className="bg-white p-6 rounded-3xl shadow-sm border border-slate-100 mt-8">
              <h4 className="font-bold text-slate-900 mb-2">Tier 3 Cities</h4>
              <p className="text-xs text-slate-500">Belgaum, Udaipur, Ranchi, Dehradun, Guwahati...</p>
            </div>
          </div>
          <div className="pt-12">
            <div className="bg-brand-orange p-8 rounded-3xl text-white shadow-xl">
              <Star className="mb-4" />
              <p className="text-lg font-bold mb-2">19 Years</p>
              <p className="text-sm opacity-80">Of clinical credibility backing your practice.</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  </section>
);

const ContactForm = () => {
  const [submitted, setSubmitted] = React.useState(false);

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
  };

  return (
    <section id="contact" className="py-24">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16">
          <div>
            <h2 className="text-4xl font-display font-bold text-slate-900 mb-6">Start Your Recovery Journey</h2>
            <p className="text-slate-600 mb-10 leading-relaxed">
              Fill out the intake form below. Dr. Saxena will review your case and confirm if online physiotherapy is the right fit for you.
            </p>
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                  <Mail size={20} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Email Us</p>
                  <p className="font-bold text-slate-900">hello@theonlinephysio.in</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                  <Phone size={20} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">WhatsApp</p>
                  <p className="font-bold text-slate-900">+91 98450 XXXXX</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                  <MapPin size={20} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Based In</p>
                  <p className="font-bold text-slate-900">Bengaluru, Karnataka</p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-white p-10 rounded-3xl shadow-2xl border border-slate-100">
            {submitted ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-brand-green/10 text-brand-green rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 size={40} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Intake Form Submitted!</h3>
                <p className="text-slate-500">We'll review your case and contact you via WhatsApp within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Full Name</label>
                    <input required type="text" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Phone (WhatsApp)</label>
                    <input required type="tel" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20" />
                  </div>
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Age</label>
                  <input required type="number" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20" />
                </div>
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Describe Your Condition</label>
                  <textarea required className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 h-32" />
                </div>
                <div className="p-4 bg-brand-yellow/20 rounded-xl text-xs text-slate-600 flex gap-3">
                  <Shield size={16} className="shrink-0" />
                  <p>Your data is processed in compliance with the DPDP Act. We ensure complete confidentiality of your medical records.</p>
                </div>
                <button type="submit" className="w-full btn-primary py-4 text-lg">Submit Intake Form</button>
              </form>
            )}
          </div>
        </div>
      </div>
    </section>
  );
};

const Footer = () => (
  <footer className="bg-slate-900 text-white py-20">
    <div className="container mx-auto px-6">
      <div className="grid grid-cols-1 md:grid-cols-4 gap-12 mb-16">
        <div className="col-span-1 md:col-span-2">
          <div className="flex items-center gap-3 mb-6">
            <div className="w-10 h-10 bg-brand-orange rounded-xl flex items-center justify-center text-white font-bold text-xl">P</div>
            <span className="font-display font-bold text-white text-2xl">The Online Physio</span>
          </div>
          <p className="text-slate-400 max-w-sm leading-relaxed">
            Professional tele-rehabilitation services by Dr. Shailendra Kumar Saxena (PT). Serving patients across India and internationally since 2010.
          </p>
        </div>
        <div>
          <h4 className="font-bold mb-6">Quick Links</h4>
          <ul className="space-y-4 text-slate-400">
            <li><a href="#about" className="hover:text-brand-orange">About</a></li>
            <li><a href="#services" className="hover:text-brand-orange">Services</a></li>
            <li><a href="#pricing" className="hover:text-brand-orange">Pricing</a></li>
            <li><a href="#partners" className="hover:text-brand-orange">Partner Network</a></li>
          </ul>
        </div>
        <div>
          <h4 className="font-bold mb-6">Connect</h4>
          <div className="flex gap-4">
            <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-brand-orange transition-all"><MessageCircle size={20} /></a>
            <a href="#" className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center hover:bg-brand-orange transition-all"><Users size={20} /></a>
          </div>
        </div>
      </div>
      <div className="pt-8 border-t border-slate-800 flex flex-col md:row justify-between items-center gap-4 text-sm text-slate-500">
        <p>© 2025 The Online Physio. All rights reserved.</p>
        <div className="flex gap-8">
          <a href="#" className="hover:text-white">Privacy Policy</a>
          <a href="#" className="hover:text-white">Terms of Service</a>
        </div>
      </div>
    </div>
  </footer>
);

export const PublicSite = () => {
  return (
    <div className="min-h-screen bg-white font-sans selection:bg-brand-orange/30">
      <Navbar />
      <Hero />
      <Services />
      <Pricing />
      <PartnerNetwork />
      <ContactForm />
      <Footer />
    </div>
  );
};
