import React from 'react';
import { 
  Users, 
  Calendar, 
  History, 
  Video, 
  CreditCard, 
  Bell, 
  Plus, 
  Search,
  CheckCircle,
  Clock,
  ExternalLink,
  QrCode,
  ArrowLeft,
  Briefcase,
  Zap
} from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';

// --- Types ---
interface Patient {
  id: number;
  name: string;
  email: string;
  phone: string;
  history: string;
  created_at: string;
}

interface Session {
  id: number;
  patient_id: number;
  patient_name: string;
  date_time: string;
  type: 'zoom' | 'whatsapp' | 'meet';
  status: string;
  payment_status: string;
  video_link: string;
  notes: string;
}

// --- Components ---

const Dashboard = ({ onNavigate }: { onNavigate: (view: string) => void }) => {
  const [sessions, setSessions] = React.useState<Session[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetch('/api/sessions')
      .then(res => res.json())
      .then(data => {
        setSessions(data);
        setLoading(false);
      });
  }, []);

  const upcomingSessions = sessions.filter(s => new Date(s.date_time) > new Date() && s.status !== 'requested');
  const pendingRequests = sessions.filter(s => s.status === 'requested');
  const todaySessions = sessions.filter(s => {
    const d = new Date(s.date_time);
    const today = new Date();
    return d.getDate() === today.getDate() && d.getMonth() === today.getMonth() && d.getFullYear() === today.getFullYear() && s.status !== 'requested';
  });

  return (
    <div className="space-y-6">
      <header className="flex justify-between items-center">
        <div>
          <h1 className="text-3xl font-display font-bold text-slate-900">Physio Dashboard</h1>
          <p className="text-slate-500">Welcome back, Dr. Shailendra</p>
        </div>
        <div className="flex gap-3">
          {pendingRequests.length > 0 && (
            <div className="flex items-center gap-2 px-4 py-2 bg-brand-orange/10 text-brand-orange rounded-xl font-bold text-sm animate-pulse">
              <Zap size={16} /> {pendingRequests.length} New Requests
            </div>
          )}
          <button 
            onClick={() => onNavigate('new-session')}
            className="btn-primary flex items-center gap-2"
          >
            <Plus size={20} /> New Session
          </button>
        </div>
      </header>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <div className="glass-card p-6 rounded-2xl">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-brand-orange/10 text-brand-orange rounded-xl">
              <Calendar size={24} />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">Today's Sessions</p>
              <p className="text-2xl font-bold text-slate-900">{todaySessions.length}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-6 rounded-2xl">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-brand-green/10 text-brand-green rounded-xl">
              <Users size={24} />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">Upcoming</p>
              <p className="text-2xl font-bold text-slate-900">{upcomingSessions.length}</p>
            </div>
          </div>
        </div>
        <div className="glass-card p-6 rounded-2xl">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-brand-yellow/20 text-yellow-700 rounded-xl">
              <CreditCard size={24} />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">Pending Payments</p>
              <p className="text-2xl font-bold text-slate-900">
                {sessions.filter(s => s.payment_status === 'pending').length}
              </p>
            </div>
          </div>
        </div>
        <div className="glass-card p-6 rounded-2xl">
          <div className="flex items-center gap-4 mb-4">
            <div className="p-3 bg-blue-100 text-blue-600 rounded-xl">
              <Bell size={24} />
            </div>
            <div>
              <p className="text-sm text-slate-500 font-medium">Reminders Due</p>
              <p className="text-2xl font-bold text-slate-900">3</p>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {pendingRequests.length > 0 && (
          <div className="glass-card rounded-2xl overflow-hidden border-brand-orange/30 border-2">
            <div className="p-6 border-b border-slate-100 flex justify-between items-center bg-brand-orange/5">
              <h2 className="text-xl font-bold text-slate-900 flex items-center gap-2">
                <Zap size={20} className="text-brand-orange" /> New Booking Requests
              </h2>
            </div>
            <div className="divide-y divide-slate-50 max-h-[400px] overflow-y-auto">
              {pendingRequests.map(request => (
                <div key={request.id} className="p-6 space-y-3 hover:bg-slate-50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div>
                      <p className="font-bold text-slate-900">{request.patient_name}</p>
                      <p className="text-xs text-slate-500">{new Date(request.date_time).toLocaleString()}</p>
                    </div>
                    <div className="flex gap-2">
                      <button 
                        onClick={() => {
                          fetch(`/api/sessions/${request.id}`, {
                            method: 'PATCH',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ status: 'scheduled' })
                          }).then(() => window.location.reload());
                        }}
                        className="px-3 py-1 bg-brand-green text-white text-xs font-bold rounded-lg hover:bg-brand-green/90"
                      >
                        Approve
                      </button>
                      <button 
                        onClick={() => {
                          fetch(`/api/sessions/${request.id}`, {
                            method: 'PATCH',
                            headers: { 'Content-Type': 'application/json' },
                            body: JSON.stringify({ status: 'cancelled' })
                          }).then(() => window.location.reload());
                        }}
                        className="px-3 py-1 bg-slate-200 text-slate-600 text-xs font-bold rounded-lg hover:bg-slate-300"
                      >
                        Decline
                      </button>
                    </div>
                  </div>
                  <p className="text-xs text-slate-600 bg-slate-100 p-2 rounded-lg italic">
                    {request.notes}
                  </p>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="p-6 border-b border-slate-100 flex justify-between items-center">
            <h2 className="text-xl font-bold text-slate-900">Today's Schedule</h2>
            <button onClick={() => onNavigate('sessions')} className="text-brand-orange font-semibold text-sm hover:underline">View All</button>
          </div>
          <div className="divide-y divide-slate-50">
            {loading ? (
              <div className="p-8 text-center text-slate-400">Loading...</div>
            ) : todaySessions.length === 0 ? (
              <div className="p-8 text-center text-slate-400">No sessions today.</div>
            ) : (
              todaySessions.map(session => (
                <div key={session.id} className="p-6 flex items-center justify-between hover:bg-slate-50 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 bg-slate-100 rounded-full flex items-center justify-center text-slate-500 font-bold">
                      {session.patient_name[0]}
                    </div>
                    <div>
                      <p className="font-bold text-slate-900">{session.patient_name}</p>
                      <p className="text-xs text-slate-500">{new Date(session.date_time).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })} · {session.type}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-2">
                    <button className="p-2 text-brand-green hover:bg-brand-green/10 rounded-lg" title="Send 30m Reminder">
                      <Bell size={18} />
                    </button>
                    <a href={session.video_link} target="_blank" className="p-2 text-brand-orange hover:bg-brand-orange/10 rounded-lg">
                      <ExternalLink size={18} />
                    </a>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>

        <div className="glass-card rounded-2xl overflow-hidden">
          <div className="p-6 border-b border-slate-100">
            <h2 className="text-xl font-bold text-slate-900">Recent Reminders</h2>
          </div>
          <div className="p-6 space-y-4">
            <div className="flex items-start gap-4 p-4 bg-yellow-50 rounded-xl border border-yellow-100">
              <Clock className="text-yellow-600 shrink-0" size={20} />
              <div>
                <p className="text-sm font-bold text-yellow-900">30 Min Prior Reminder</p>
                <p className="text-xs text-yellow-700">Patient: Ramesh K. · Session at 10:30 AM</p>
                <button className="mt-2 text-xs font-bold text-yellow-800 underline">Send WhatsApp Reminder</button>
              </div>
            </div>
            <div className="flex items-start gap-4 p-4 bg-blue-50 rounded-xl border border-blue-100">
              <History className="text-blue-600 shrink-0" size={20} />
              <div>
                <p className="text-sm font-bold text-blue-900">Follow-up Reminder</p>
                <p className="text-xs text-blue-700">Patient: Sudha M. · Last session 7 days ago</p>
                <button className="mt-2 text-xs font-bold text-blue-800 underline">Schedule Follow-up</button>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

const PatientList = () => {
  const [patients, setPatients] = React.useState<Patient[]>([]);
  const [search, setSearch] = React.useState('');

  React.useEffect(() => {
    fetch('/api/patients').then(res => res.json()).then(setPatients);
  }, []);

  const filtered = patients.filter(p => p.name.toLowerCase().includes(search.toLowerCase()) || p.phone.includes(search));

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-display font-bold text-slate-900">Patient Records</h1>
        <div className="relative">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400" size={18} />
          <input 
            type="text" 
            placeholder="Search patients..." 
            className="pl-10 pr-4 py-2 bg-white border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-brand-orange/20 focus:border-brand-orange transition-all"
            value={search}
            onChange={e => setSearch(e.target.value)}
          />
        </div>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {filtered.map(patient => (
          <motion.div 
            layout
            key={patient.id} 
            className="glass-card p-6 rounded-2xl flex justify-between items-start"
          >
            <div className="space-y-2">
              <h3 className="text-xl font-bold text-slate-900">{patient.name}</h3>
              <div className="flex gap-4 text-sm text-slate-500">
                <span>{patient.phone}</span>
                <span>{patient.email}</span>
              </div>
              <div className="mt-4 p-4 bg-slate-50 rounded-xl text-sm text-slate-600">
                <p className="font-semibold mb-1">History:</p>
                {patient.history || 'No history recorded.'}
              </div>
            </div>
            <button className="text-brand-orange font-bold text-sm hover:underline flex items-center gap-1">
              <History size={16} /> View Full History
            </button>
          </motion.div>
        ))}
      </div>
    </div>
  );
};

const NewSessionForm = ({ onComplete }: { onComplete: () => void }) => {
  const [patients, setPatients] = React.useState<Patient[]>([]);
  const [formData, setFormData] = React.useState({
    patient_id: '',
    date_time: '',
    type: 'zoom',
    video_link: '',
    notes: ''
  });

  React.useEffect(() => {
    fetch('/api/patients').then(res => res.json()).then(setPatients);
  }, []);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    await fetch('/api/sessions', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(formData)
    });
    onComplete();
  };

  return (
    <div className="max-w-2xl mx-auto">
      <div className="glass-card p-8 rounded-2xl">
        <h2 className="text-2xl font-display font-bold text-slate-900 mb-6">Schedule New Session</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div className="space-y-1">
            <label className="text-sm font-bold text-slate-700">Select Patient</label>
            <select 
              required
              className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20"
              value={formData.patient_id}
              onChange={e => setFormData({...formData, patient_id: e.target.value})}
            >
              <option value="">Choose a patient...</option>
              {patients.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
            </select>
          </div>
          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-1">
              <label className="text-sm font-bold text-slate-700">Date & Time</label>
              <input 
                type="datetime-local" 
                required
                className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20"
                value={formData.date_time}
                onChange={e => setFormData({...formData, date_time: e.target.value})}
              />
            </div>
            <div className="space-y-1">
              <label className="text-sm font-bold text-slate-700">Platform</label>
              <select 
                className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20"
                value={formData.type}
                onChange={e => setFormData({...formData, type: e.target.value as any})}
              >
                <option value="zoom">Zoom</option>
                <option value="whatsapp">WhatsApp</option>
                <option value="meet">Google Meet</option>
              </select>
            </div>
          </div>
          <div className="space-y-1">
            <label className="text-sm font-bold text-slate-700">Video Link</label>
            <input 
              type="url" 
              placeholder="https://..."
              className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20"
              value={formData.video_link}
              onChange={e => setFormData({...formData, video_link: e.target.value})}
            />
          </div>
          <div className="space-y-1">
            <label className="text-sm font-bold text-slate-700">Notes</label>
            <textarea 
              className="w-full p-3 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 h-32"
              value={formData.notes}
              onChange={e => setFormData({...formData, notes: e.target.value})}
            />
          </div>
          <div className="pt-4 flex gap-4">
            <button type="button" onClick={onComplete} className="flex-1 px-6 py-3 border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-all">Cancel</button>
            <button type="submit" className="flex-1 btn-primary">Schedule Session</button>
          </div>
        </form>
      </div>
    </div>
  );
};

const PartnerManagement = () => {
  const [partners, setPartners] = React.useState<any[]>([]);
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetch('/api/partners').then(res => res.json()).then(data => {
      setPartners(data);
      setLoading(false);
    });
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h1 className="text-3xl font-display font-bold text-slate-900">Partner Network</h1>
        <button className="btn-primary flex items-center gap-2">
          <Plus size={20} /> Add Partner
        </button>
      </div>

      <div className="glass-card rounded-2xl overflow-hidden">
        <table className="w-full text-left">
          <thead className="bg-slate-50 border-b border-slate-100">
            <tr>
              <th className="p-4 font-bold text-slate-700">Name</th>
              <th className="p-4 font-bold text-slate-700">City</th>
              <th className="p-4 font-bold text-slate-700">Status</th>
              <th className="p-4 font-bold text-slate-700">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-50">
            {loading ? (
              <tr><td colSpan={4} className="p-8 text-center text-slate-400">Loading...</td></tr>
            ) : partners.length === 0 ? (
              <tr><td colSpan={4} className="p-8 text-center text-slate-400">No partners added yet.</td></tr>
            ) : (
              partners.map(p => (
                <tr key={p.id} className="hover:bg-slate-50 transition-colors">
                  <td className="p-4 font-bold text-slate-900">{p.name}</td>
                  <td className="p-4 text-slate-600">{p.city}</td>
                  <td className="p-4">
                    <span className="px-2 py-1 bg-green-100 text-green-700 rounded-lg text-xs font-bold uppercase">Active</span>
                  </td>
                  <td className="p-4">
                    <button className="text-brand-orange font-bold text-sm">Edit</button>
                  </td>
                </tr>
              ))
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export const AdminApp = () => {
  const [view, setView] = React.useState('dashboard');

  const renderView = () => {
    switch(view) {
      case 'dashboard': return <Dashboard onNavigate={setView} />;
      case 'patients': return <PatientList />;
      case 'partners': return <PartnerManagement />;
      case 'new-session': return <NewSessionForm onComplete={() => setView('dashboard')} />;
      default: return <Dashboard onNavigate={setView} />;
    }
  };

  return (
    <div className="min-h-screen bg-slate-50 flex">
      {/* Sidebar */}
      <aside className="w-64 bg-white border-r border-slate-200 p-6 flex flex-col gap-8">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-brand-orange rounded-xl flex items-center justify-center text-white font-bold text-xl">P</div>
          <span className="font-display font-bold text-slate-900 text-lg">Admin Panel</span>
        </div>

        <nav className="flex flex-col gap-2">
          <button 
            onClick={() => setView('dashboard')}
            className={`flex items-center gap-3 p-3 rounded-xl font-semibold transition-all ${view === 'dashboard' ? 'bg-brand-orange/10 text-brand-orange' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Calendar size={20} /> Dashboard
          </button>
          <button 
            onClick={() => setView('patients')}
            className={`flex items-center gap-3 p-3 rounded-xl font-semibold transition-all ${view === 'patients' ? 'bg-brand-orange/10 text-brand-orange' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Users size={20} /> Patients
          </button>
          <button 
            onClick={() => setView('partners')}
            className={`flex items-center gap-3 p-3 rounded-xl font-semibold transition-all ${view === 'partners' ? 'bg-brand-orange/10 text-brand-orange' : 'text-slate-500 hover:bg-slate-50'}`}
          >
            <Briefcase size={20} /> Partners
          </button>
          <button 
            className="flex items-center gap-3 p-3 rounded-xl font-semibold text-slate-500 hover:bg-slate-50 transition-all"
          >
            <Bell size={20} /> Reminders
          </button>
          <button 
            className="flex items-center gap-3 p-3 rounded-xl font-semibold text-slate-500 hover:bg-slate-50 transition-all"
          >
            <CreditCard size={20} /> Payments
          </button>
        </nav>

        <div className="mt-auto p-4 bg-brand-yellow/20 rounded-2xl border border-brand-yellow/30">
          <div className="flex items-center gap-2 text-yellow-800 font-bold mb-2">
            <QrCode size={18} /> Payment QR
          </div>
          <div className="bg-white p-2 rounded-lg aspect-square flex items-center justify-center border border-brand-yellow/50">
            <div className="text-[10px] text-slate-400 text-center">HDFC Vyapar QR Placeholder</div>
          </div>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-8 overflow-y-auto">
        <AnimatePresence mode="wait">
          <motion.div
            key={view}
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -10 }}
            transition={{ duration: 0.2 }}
          >
            {renderView()}
          </motion.div>
        </AnimatePresence>
      </main>
    </div>
  );
};
