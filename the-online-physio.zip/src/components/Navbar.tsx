import React from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';

export const Navbar = () => {
  const [isOpen, setIsOpen] = React.useState(false);
  const location = useLocation();

  const links = [
    { name: 'Home', path: '/' },
    { name: 'The Physio Way', path: '/physio-way' },
    { name: 'Online Physio', path: '/online-physio' },
    { name: 'Your Physio', path: '/your-physio' },
    { name: 'Conditions', path: '/services' },
    { name: 'Partner Network', path: '/partner-network' },
    ...(process.env.VITE_LAUNCH_PARTNERS === 'true' ? [{ name: 'Partners', path: '/partners' }] : []),
    { name: 'Appointments', path: '/appointments' },
  ];

  return (
    <nav className="sticky top-0 z-50 bg-white/80 backdrop-blur-lg border-b border-slate-100">
      <div className="container mx-auto px-6 h-20 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-3">
          <div className="w-10 h-10 bg-brand-orange rounded-xl flex items-center justify-center text-white font-bold text-xl">P</div>
          <div className="flex flex-col leading-tight">
            <span className="font-display font-bold text-slate-900 text-lg">The Online Physio</span>
            <span className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Dr. Shailendra Saxena</span>
          </div>
        </Link>

        {/* Desktop Links */}
        <div className="hidden xl:flex items-center gap-6">
          {links.map(link => (
            <Link 
              key={link.path} 
              to={link.path} 
              className={`text-sm font-bold transition-colors ${location.pathname === link.path ? 'text-brand-orange' : 'text-slate-500 hover:text-brand-orange'}`}
            >
              {link.name}
            </Link>
          ))}
          <Link to="/appointments" className="btn-primary py-2 px-6 text-sm">Book Now</Link>
        </div>

        {/* Mobile Toggle */}
        <button className="xl:hidden text-slate-900" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <X size={28} /> : <Menu size={28} />}
        </button>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="xl:hidden bg-white border-b border-slate-100 p-6 space-y-4">
          {links.map(link => (
            <Link 
              key={link.path} 
              to={link.path} 
              onClick={() => setIsOpen(false)}
              className={`block text-lg font-bold ${location.pathname === link.path ? 'text-brand-orange' : 'text-slate-900'}`}
            >
              {link.name}
            </Link>
          ))}
          <Link to="/appointments" onClick={() => setIsOpen(false)} className="btn-primary w-full block text-center">Book Now</Link>
        </div>
      )}
    </nav>
  );
};
