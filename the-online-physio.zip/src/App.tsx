import React from 'react';
import { BrowserRouter as Router, Routes, Route, useLocation } from 'react-router-dom';
import { Navbar } from './components/Navbar';
import { Home } from './pages/Home';
import { YourPhysio } from './pages/YourPhysio';
import { PartnerNetwork } from './pages/PartnerNetwork';
import { Services } from './pages/Services';
import { Pricing } from './pages/Pricing';
import { PhysioWay } from './pages/PhysioWay';
import { OnlinePhysio } from './pages/OnlinePhysio';
import { PartnerList } from './pages/PartnerList';
import { AdminApp } from './components/AdminApp';
import { ChatWidget } from './components/ChatWidget';

const AppContent = () => {
  const location = useLocation();
  const isAdmin = location.pathname.startsWith('/admin');

  if (isAdmin) {
    return <AdminApp />;
  }

  return (
    <div className="relative">
      <Navbar />
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/your-physio" element={<YourPhysio />} />
        <Route path="/partner-network" element={<PartnerNetwork />} />
        <Route path="/services" element={<Services />} />
        <Route path="/appointments" element={<Pricing />} />
        <Route path="/physio-way" element={<PhysioWay />} />
        <Route path="/online-physio" element={<OnlinePhysio />} />
        {process.env.VITE_LAUNCH_PARTNERS === 'true' && (
          <Route path="/partners" element={<PartnerList />} />
        )}
      </Routes>
      
      <ChatWidget />
      
      {/* Admin Access Toggle (Hidden or subtle in production) */}
      <button 
        onClick={() => {
          window.location.href = '/admin';
        }}
        className="fixed bottom-4 left-4 w-8 h-8 bg-slate-200/50 hover:bg-slate-300 rounded-full flex items-center justify-center text-slate-400 transition-all z-50 opacity-20 hover:opacity-100"
        title="Admin Dashboard"
      >
        <div className="w-2 h-2 bg-slate-400 rounded-full" />
      </button>

      {/* GoDaddy Integration Guide (Only visible in dev/preview) */}
      <div className="fixed bottom-4 right-4 z-50">
        <button 
          onClick={() => alert(`
GoDaddy Integration Guide:
1. Go to your GoDaddy Website Builder.
2. Add a new "HTML" or "Embed" section.
3. Paste the following snippet:
   <iframe 
     src="${window.location.origin}" 
     style="width:100%; height:900px; border:none;"
   ></iframe>
4. To embed specific pages, use the full URL, e.g.:
   <iframe 
     src="${window.location.origin}/appointments" 
     style="width:100%; height:800px; border:none;"
   ></iframe>
          `)}
          className="bg-slate-900 text-white px-4 py-2 rounded-full text-xs font-bold shadow-xl flex items-center gap-2"
        >
          <span>GoDaddy Guide</span>
        </button>
      </div>
    </div>
  );
};

export default function App() {
  return (
    <Router>
      <AppContent />
    </Router>
  );
}
