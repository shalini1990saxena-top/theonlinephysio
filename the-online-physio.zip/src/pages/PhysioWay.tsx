import React from 'react';
import { motion } from 'motion/react';
import { Target, Heart, Zap, Shield, CheckCircle2 } from 'lucide-react';

export const PhysioWay = () => {
  return (
    <div className="min-h-screen py-24">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <span className="text-brand-orange font-bold text-sm tracking-widest uppercase block">Methodology</span>
            <h1 className="text-5xl font-display font-black text-slate-900">The Physio Way</h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Integrative pain management and injury rehabilitation rooted in evidence and patient empowerment.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-4">
              <Target className="text-brand-orange" size={32} />
              <h3 className="text-2xl font-bold text-slate-900">Diagnosis First</h3>
              <p className="text-slate-600">We don't just treat symptoms. We dive deep into your clinical history and movement patterns to identify the root cause of your pain.</p>
            </div>
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-4">
              <Heart className="text-brand-green" size={32} />
              <h3 className="text-2xl font-bold text-slate-900">Patient Centered</h3>
              <p className="text-slate-600">Your goals are our goals. Whether it's returning to sports or playing with your grandkids, we tailor your plan to your life.</p>
            </div>
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-4">
              <Zap className="text-brand-yellow" size={32} />
              <h3 className="text-2xl font-bold text-slate-900">Empowerment</h3>
              <p className="text-slate-600">We teach you how to manage your condition. Knowledge is the most powerful tool in long-term recovery.</p>
            </div>
            <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100 space-y-4">
              <Shield className="text-blue-500" size={32} />
              <h3 className="text-2xl font-bold text-slate-900">Evidence Based</h3>
              <p className="text-slate-600">Every protocol we use is backed by clinical research and nearly two decades of real-world experience.</p>
            </div>
          </div>

          <div className="bg-slate-900 text-white p-12 rounded-3xl space-y-6">
            <h2 className="text-3xl font-display font-bold text-brand-orange">Our Commitment</h2>
            <p className="text-lg text-slate-300 leading-relaxed">
              We believe that recovery is a partnership. While we provide the expertise and the roadmap, your commitment to the process is what drives results. Together, we build a path to lasting health.
            </p>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {[
                "No over-treatment",
                "Honest clinical advice",
                "Transparent progress tracking",
                "Continuous support"
              ].map((item, i) => (
                <div key={i} className="flex items-center gap-3">
                  <CheckCircle2 className="text-brand-green" size={20} />
                  <span className="font-semibold">{item}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
