import React from 'react';
import { motion } from 'motion/react';
import { Award, GraduationCap, MapPin, Laptop, Globe, CheckCircle2 } from 'lucide-react';
import { DoctorPhoto } from '../components/DoctorPhoto';

export const YourPhysio = () => {
  return (
    <div className="min-h-screen py-24">
      <div className="container mx-auto px-6">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
          <div className="relative">
            <div className="absolute inset-0 bg-brand-yellow/20 rounded-3xl -rotate-6 translate-x-4 translate-y-4 -z-10" />
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl border-8 border-white bg-white">
              <DoctorPhoto className="w-full h-auto" />
            </div>
            <div className="absolute -bottom-6 -right-6 z-20 glass-card p-6 rounded-2xl max-w-xs">
              <div className="flex items-center gap-3 mb-2">
                <Award className="text-brand-orange" />
                <span className="font-bold text-slate-900">NDTV Featured</span>
              </div>
              <p className="text-sm text-slate-500">Recognized as a pioneer in Indian tele-rehabilitation services.</p>
            </div>
          </div>
          <div className="space-y-8">
            <div className="space-y-4">
              <span className="text-brand-orange font-bold text-sm tracking-widest uppercase mb-4 block">About the Doctor</span>
              <h1 className="text-5xl font-display font-black text-slate-900 leading-tight">
                Meet Dr. Shailendra <br />
                <span className="text-brand-orange">Kumar Saxena (PT)</span>
              </h1>
            </div>
            
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl">
                <div className="w-12 h-12 bg-brand-orange/10 text-brand-orange rounded-xl flex items-center justify-center">
                  <GraduationCap size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase">Experience</p>
                  <p className="font-bold text-slate-900">19+ Years Clinical</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl">
                <div className="w-12 h-12 bg-brand-green/10 text-brand-green rounded-xl flex items-center justify-center">
                  <Laptop size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase">Tele-Rehab</p>
                  <p className="font-bold text-slate-900">14+ Yrs Pioneer</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl">
                <div className="w-12 h-12 bg-brand-yellow/20 text-yellow-700 rounded-xl flex items-center justify-center">
                  <MapPin size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase">Based In</p>
                  <p className="font-bold text-slate-900">Bengaluru, Karnataka</p>
                </div>
              </div>
              <div className="flex items-center gap-4 p-4 bg-slate-50 rounded-2xl">
                <div className="w-12 h-12 bg-blue-50 text-blue-500 rounded-xl flex items-center justify-center">
                  <Globe size={24} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase">Serving</p>
                  <p className="font-bold text-slate-900">Pan-India & International</p>
                </div>
              </div>
            </div>

            <div className="space-y-4 text-lg text-slate-600 leading-relaxed">
              <p>
                Dr. Shailendra Kumar Saxena (P.T) is a Bangalore-based physiotherapist with 19+ years of clinical experience. Having pioneered online physiotherapy initiatives for over 14 years, he specializes in integrative pain management and digital healthcare, helping patients across different cities and countries reclaim their physical health.
              </p>
              <p>
                His practice is rooted in integrative pain management, combining evidence-based physiotherapy with patient education, lifestyle modification, and digital tools to deliver measurable outcomes from anywhere in India or the world.
              </p>
            </div>

            <div className="bg-brand-orange/5 border-l-4 border-brand-orange p-8 rounded-r-3xl italic text-slate-700 text-lg">
              "Bengaluru-based, serving pan India. Tele-rehabilitation and online pain management are my field of expertise as a physiotherapist with two decades of experience. My online consultations are helpful for patients who are willing to take control of their health."
              <cite className="block mt-4 font-bold not-italic text-sm text-slate-900">— Dr. Shailendra Kumar Saxena (PT)</cite>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
