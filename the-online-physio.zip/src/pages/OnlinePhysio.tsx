import React from 'react';
import { motion } from 'motion/react';
import { Video, Clock, Globe, Shield, CheckCircle2, ArrowRight } from 'lucide-react';

export const OnlinePhysio = () => {
  return (
    <div className="min-h-screen py-24">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <span className="text-brand-orange font-bold text-sm tracking-widest uppercase block">Tele-Rehabilitation</span>
            <h1 className="text-5xl font-display font-black text-slate-900">Online Physiotherapy</h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Expert care delivered digitally. Recovery reimagined for the modern world.
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-slate-900">How it Works</h3>
              <p className="text-slate-600 text-lg leading-relaxed">
                Online physiotherapy is a highly effective way to manage pain and injury. Through secure video calls, we can assess your movement, diagnose your condition, and guide you through a personalized rehabilitation plan.
              </p>
              <div className="space-y-4">
                {[
                  "Secure Video Consultations",
                  "Digital Exercise Prescriptions",
                  "Progress Monitoring via WhatsApp",
                  "Flexible Scheduling",
                  "No Travel Required"
                ].map((item, i) => (
                  <div key={i} className="flex items-center gap-3">
                    <CheckCircle2 className="text-brand-green" size={20} />
                    <span className="font-semibold text-slate-700">{item}</span>
                  </div>
                ))}
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div className="bg-brand-orange/10 p-8 rounded-3xl flex flex-col items-center justify-center text-center space-y-4">
                <Video className="text-brand-orange" size={40} />
                <p className="font-bold text-slate-900">Live Video</p>
              </div>
              <div className="bg-brand-green/10 p-8 rounded-3xl flex flex-col items-center justify-center text-center space-y-4">
                <Clock className="text-brand-green" size={40} />
                <p className="font-bold text-slate-900">Flexible Time</p>
              </div>
              <div className="bg-brand-yellow/20 p-8 rounded-3xl flex flex-col items-center justify-center text-center space-y-4">
                <Globe className="text-yellow-700" size={40} />
                <p className="font-bold text-slate-900">Pan-India</p>
              </div>
              <div className="bg-blue-50 p-8 rounded-3xl flex flex-col items-center justify-center text-center space-y-4">
                <Shield className="text-blue-500" size={40} />
                <p className="font-bold text-slate-900">Secure Data</p>
              </div>
            </div>
          </div>

          <div className="bg-slate-50 p-12 rounded-3xl space-y-8">
            <h2 className="text-3xl font-display font-bold text-slate-900 text-center">Frequently Asked Questions</h2>
            <div className="space-y-6">
              {[
                { q: "Is online physio as effective as in-person?", a: "Yes. For most musculoskeletal conditions, research shows that online physiotherapy is just as effective as in-person care, with the added benefit of higher patient adherence." },
                { q: "What equipment do I need?", a: "Most patients only need their smartphone or laptop. We use household items for exercises whenever possible." },
                { q: "How do I share my reports?", a: "You can upload them securely through our intake form or share them via WhatsApp after booking." }
              ].map((faq, i) => (
                <div key={i} className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                  <h4 className="font-bold text-slate-900 mb-2">{faq.q}</h4>
                  <p className="text-slate-600 text-sm">{faq.a}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
