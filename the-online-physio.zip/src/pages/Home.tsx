import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, Award, Activity, Shield, ArrowRight, Video, Clock, Users } from 'lucide-react';
import { Link } from 'react-router-dom';
import { DoctorPhoto } from '../components/DoctorPhoto';

export const Home = () => {
  return (
    <div className="min-h-screen">
      {/* Hero Section */}
      <section className="relative pt-20 pb-32 overflow-hidden bg-gradient-to-br from-white via-brand-green/5 to-brand-yellow/5">
        <div className="container mx-auto px-6 grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
          <motion.div 
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            className="space-y-8"
          >
            <div className="inline-flex items-center gap-2 px-4 py-2 bg-brand-green/10 text-brand-green rounded-full text-sm font-bold">
              <CheckCircle2 size={16} /> 19+ Years of Clinical Excellence
            </div>
            <h1 className="text-6xl md:text-7xl font-display font-black text-slate-900 leading-tight">
              Heal Better. <br />
              <span className="text-brand-orange">From Anywhere.</span>
            </h1>
            <p className="text-xl text-slate-600 max-w-lg leading-relaxed">
              Dr. Shailendra Kumar Saxena (P.T) is a Bangalore-based physiotherapist with 19+ years of clinical experience. Having pioneered online physiotherapy initiatives for over 14 years, he specializes in integrative pain management and digital healthcare, helping patients across different cities and countries reclaim their physical health.
            </p>
            <div className="flex flex-wrap gap-4">
              <Link to="/appointments" className="btn-primary text-lg px-8 py-4">Book a Consultation</Link>
              <Link to="/physio-way" className="px-8 py-4 rounded-xl font-bold text-slate-600 hover:bg-slate-100 transition-all">The Physio Way</Link>
            </div>
            <div className="flex items-center gap-8 pt-4">
              <div className="flex -space-x-4">
                {[1,2,3,4].map(i => (
                  <div key={i} className="w-12 h-12 rounded-full border-4 border-white bg-slate-200 overflow-hidden">
                    <img src={`https://picsum.photos/seed/${i+10}/100/100`} alt="Patient" referrerPolicy="no-referrer" />
                  </div>
                ))}
              </div>
              <p className="text-sm font-semibold text-slate-500">Trusted by 500+ patients across India</p>
            </div>
          </motion.div>
          <motion.div 
            initial={{ opacity: 0, scale: 0.9 }}
            animate={{ opacity: 1, scale: 1 }}
            className="relative"
          >
            <div className="relative z-10 rounded-3xl overflow-hidden shadow-2xl border-8 border-white bg-white">
              <DoctorPhoto className="w-full h-auto" />
            </div>
            <div className="absolute -bottom-6 -left-6 z-20 glass-card p-6 rounded-2xl max-w-xs">
              <div className="flex items-center gap-3 mb-2">
                <Award className="text-brand-orange" />
                <span className="font-bold text-slate-900">NDTV Featured</span>
              </div>
              <p className="text-sm text-slate-500">Recognized as a pioneer in Indian tele-rehabilitation services.</p>
            </div>
          </motion.div>
        </div>
      </section>

      {/* Stats Bar */}
      <div className="bg-slate-900 py-12">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 text-center">
            <div>
              <p className="text-4xl font-display font-black text-brand-orange">19+</p>
              <p className="text-slate-400 text-sm font-bold uppercase tracking-wider">Years Experience</p>
            </div>
            <div>
              <p className="text-4xl font-display font-black text-brand-green">14+</p>
              <p className="text-slate-400 text-sm font-bold uppercase tracking-wider">Yrs Online Practice</p>
            </div>
            <div>
              <p className="text-4xl font-display font-black text-brand-yellow">500+</p>
              <p className="text-slate-400 text-sm font-bold uppercase tracking-wider">Online Patients</p>
            </div>
            <div>
              <p className="text-4xl font-display font-black text-white">24hr</p>
              <p className="text-slate-400 text-sm font-bold uppercase tracking-wider">Response Time</p>
            </div>
          </div>
        </div>
      </div>

      {/* Quick Intro */}
      <section className="py-24 container mx-auto px-6">
        <div className="max-w-3xl mx-auto text-center space-y-6">
          <h2 className="text-4xl font-display font-bold text-slate-900">Pioneering online pain management in India</h2>
          <p className="text-lg text-slate-600 leading-relaxed">
            Bengaluru-based, serving pan India. Telerehabilitation and online pain management are my field of expertise as a physiotherapist with two decades of experience. My online physiotherapy consultations are helpful for patients who are willing to take control of their health.
          </p>
          <div className="pt-8">
            <Link to="/your-physio" className="text-brand-orange font-bold flex items-center justify-center gap-2 hover:gap-4 transition-all">
              Meet Dr. Shailendra Kumar Saxena PT <ArrowRight size={20} />
            </Link>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-6">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-12">
            <div className="space-y-4">
              <div className="w-16 h-16 bg-brand-orange/10 text-brand-orange rounded-2xl flex items-center justify-center">
                <Video size={32} />
              </div>
              <h3 className="text-2xl font-bold text-slate-900">Tele-Rehabilitation</h3>
              <p className="text-slate-600">Secure video consultations from anywhere. No travel, no waiting rooms, just expert care.</p>
            </div>
            <div className="space-y-4">
              <div className="w-16 h-16 bg-brand-green/10 text-brand-green rounded-2xl flex items-center justify-center">
                <Activity size={32} />
              </div>
              <h3 className="text-2xl font-bold text-slate-900">Pain Management</h3>
              <p className="text-slate-600">Specialized protocols for chronic back pain, disc issues, and arthritis management.</p>
            </div>
            <div className="space-y-4">
              <div className="w-16 h-16 bg-brand-yellow/20 text-yellow-700 rounded-2xl flex items-center justify-center">
                <Shield size={32} />
              </div>
              <h3 className="text-2xl font-bold text-slate-900">DPDP Compliant</h3>
              <p className="text-slate-600">Your medical data is protected under India's Digital Personal Data Protection Act.</p>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
};
