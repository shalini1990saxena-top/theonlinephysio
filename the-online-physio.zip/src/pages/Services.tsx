import React from 'react';
import { motion } from 'motion/react';
import { Activity, Stethoscope, Shield, Award, Users, Heart, Zap, Dumbbell } from 'lucide-react';

const ConditionCard = ({ title, icon, description, color }: any) => (
  <motion.div 
    whileHover={{ y: -5 }}
    className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100"
  >
    <div className={`w-14 h-14 ${color} rounded-2xl flex items-center justify-center mb-6`}>
      {React.cloneElement(icon, { size: 28 })}
    </div>
    <h3 className="text-xl font-bold text-slate-900 mb-3">{title}</h3>
    <p className="text-slate-500 text-sm leading-relaxed">{description}</p>
  </motion.div>
);

export const Services = () => {
  const conditions = [
    { title: "Back Pain & Disc Issues", icon: <Activity />, description: "Specialized protocols for chronic back pain, sciatica, disc herniation and lumbar health.", color: "bg-orange-50 text-brand-orange" },
    { title: "Arthritis Management", icon: <Stethoscope />, description: "Personalized movement plans to reduce joint stiffness and improve range of motion in Osteoarthritis and Rheumatoid Arthritis.", color: "bg-green-50 text-brand-green" },
    { title: "Neck Pain & Cervical", icon: <Zap />, description: "Assessment and treatment of cervical spondylosis, postural neck pain and radiculopathy.", color: "bg-yellow-50 text-yellow-600" },
    { title: "Post-COVID Rehabilitation", icon: <Shield />, description: "Respiratory and physical rehabilitation after viral infections, including long-COVID fatigue protocols.", color: "bg-blue-50 text-blue-500" },
    { title: "Injury & Sports Rehab", icon: <Award />, description: "Professional recovery plans for ligament injuries, muscle strains and sports-related conditions.", color: "bg-purple-50 text-purple-500" },
    { title: "Geriatric Care", icon: <Users />, description: "Preventive physical therapy for seniors to maintain mobility and reduce fall risk from home.", color: "bg-pink-50 text-pink-500" },
    { title: "Pre-Exercise Assessments", icon: <Dumbbell />, description: "Expert advice before starting Yoga, Gym, or Pilates to train safely and avoid injury.", color: "bg-indigo-50 text-indigo-500" },
    { title: "Integrative Pain Care", icon: <Heart />, description: "Combining evidence-based physiotherapy with patient education and lifestyle modification.", color: "bg-red-50 text-red-500" },
  ];

  return (
    <div className="min-h-screen py-24">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-brand-orange font-bold text-sm tracking-widest uppercase mb-4 block">Conditions We Treat</span>
          <h1 className="text-5xl font-display font-black text-slate-900 mb-6 leading-tight">
            Comprehensive Care <br />
            <span className="text-brand-orange">For Every Condition</span>
          </h1>
          <p className="text-lg text-slate-600 leading-relaxed">
            From chronic pain to post-surgical rehabilitation, we provide expert online guidance tailored to your specific recovery goals.
          </p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
          {conditions.map((c, i) => (
            <ConditionCard key={i} {...c} />
          ))}
        </div>
      </div>
    </div>
  );
};
