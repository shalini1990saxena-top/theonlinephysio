import React from 'react';
import { motion } from 'motion/react';
import { CheckCircle2, ArrowRight, Users, Award, Lightbulb, MapPin, Briefcase } from 'lucide-react';

export const PartnerNetwork = () => {
  return (
    <div className="min-h-screen">
      {/* Hero */}
      <section className="bg-slate-900 text-white py-24">
        <div className="container mx-auto px-6 text-center space-y-8">
          <h1 className="text-5xl md:text-6xl font-display font-black text-brand-orange">
            Join The Physical Health Consultants Partner Network
          </h1>
          <p className="text-2xl text-slate-300 max-w-3xl mx-auto font-semibold">
            Your Practice. Our Expertise. Better Patient Care Together.
          </p>
          <div className="pt-8">
            <a href="mailto:hello@theonlinephysio.in" className="btn-primary text-lg px-10 py-4">Apply to Join the Network</a>
          </div>
        </div>
      </section>

      {/* Intro */}
      <section className="py-24 container mx-auto px-6">
        <div className="max-w-4xl mx-auto space-y-8 text-lg text-slate-600 leading-relaxed">
          <p className="font-bold text-slate-900 text-xl">Dear Fellow Physiotherapy Professional,</p>
          <p>
            Are you building your practice in the early years of your career? Looking to establish your reputation and grow your patient base in your city?
          </p>
          <p>
            I'm reaching out with a unique opportunity designed specifically for physiotherapy professionals with 1-5 years of experience who are establishing themselves in tier 2 and tier 3 cities across India.
          </p>
          <p>
            The Online Physio, based in Bangalore with 19 years of clinical experience and over a decade of proven telehealth expertise, is building a select network of trusted partner physiotherapists. This collaboration is designed to help you grow while ensuring patients across India receive the highest quality care—whether online or in-clinic.
          </p>
        </div>
      </section>

      {/* How it works */}
      <section className="py-24 bg-slate-50">
        <div className="container mx-auto px-6">
          <h2 className="text-4xl font-display font-bold text-slate-900 text-center mb-16">How This Partnership Works</h2>
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-16 items-center">
            <div className="space-y-6">
              <h3 className="text-2xl font-bold text-slate-900">The Patient Journey & Your Role</h3>
              <p className="text-slate-600 text-lg">
                Every week, patients from cities across India reach out to The Online Physio. Sometimes they find us through referrals, other times through direct online searches.
              </p>
              <div className="bg-white p-8 rounded-3xl shadow-sm border border-slate-100">
                <p className="font-bold text-brand-orange mb-4">Here's where you come in:</p>
                <p className="text-slate-600">
                  While our telehealth methodology works perfectly for many cases, certain conditions require hands-on, in-clinic assessment and treatment. When patients from your city contact us and need in-person sessions, we'll refer them directly to you, bringing you patients who already trust the expertise behind The Online Physio brand.
                </p>
              </div>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <Users className="text-brand-orange mb-4" size={32} />
                <h4 className="font-bold text-slate-900 mb-2">Direct Referrals</h4>
                <p className="text-sm text-slate-500">Receive patients from your city who contact us but need in-person treatment.</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <Award className="text-brand-green mb-4" size={32} />
                <h4 className="font-bold text-slate-900 mb-2">Professional Recognition</h4>
                <p className="text-sm text-slate-500">Get featured on our website and display "Powered by The Online Physio" branding.</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <Lightbulb className="text-brand-yellow mb-4" size={32} />
                <h4 className="font-bold text-slate-900 mb-2">Clinical Mentorship</h4>
                <p className="text-sm text-slate-500">Access case consultations and treatment planning support from Dr. Shailendra.</p>
              </div>
              <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-100">
                <Briefcase className="text-blue-500 mb-4" size={32} />
                <h4 className="font-bold text-slate-900 mb-2">Growth Acceleration</h4>
                <p className="text-sm text-slate-500">Supplement your practice with referred cases and build trust faster.</p>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Cities */}
      <section className="py-24 container mx-auto px-6">
        <div className="text-center max-w-3xl mx-auto mb-16">
          <h2 className="text-4xl font-display font-bold text-slate-900 mb-6">Cities We're Currently Building Our Network In</h2>
          <p className="text-slate-600">If your city isn't listed, reach out—we're expanding across India.</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <MapPin className="text-brand-orange" /> Tier 2 Cities
            </h3>
            <div className="flex flex-wrap gap-2">
              {["Mysore", "Mangalore", "Hubli", "Coimbatore", "Madurai", "Trichy", "Vijayawada", "Visakhapatnam", "Nashik", "Aurangabad", "Rajkot", "Vadodara", "Jaipur", "Indore", "Bhopal", "Lucknow", "Kanpur", "Raipur", "Patna"].map(city => (
                <span key={city} className="px-4 py-2 bg-slate-100 rounded-full text-sm font-semibold text-slate-700">{city}</span>
              ))}
            </div>
          </div>
          <div className="space-y-6">
            <h3 className="text-xl font-bold text-slate-900 flex items-center gap-2">
              <MapPin className="text-brand-green" /> Tier 3 Cities
            </h3>
            <div className="flex flex-wrap gap-2">
              {["Belgaum", "Shimoga", "Tumkur", "Salem", "Tirunelveli", "Erode", "Vellore", "Guntur", "Kakinada", "Nellore", "Kolhapur", "Jalgaon", "Akola", "Gandhidham", "Bhavnagar", "Ajmer", "Kota", "Udaipur", "Jodhpur", "Jabalpur", "Gwalior", "Dehradun", "Ranchi", "Guwahati"].map(city => (
                <span key={city} className="px-4 py-2 bg-slate-100 rounded-full text-sm font-semibold text-slate-700">{city}</span>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="py-24 bg-brand-orange/10">
        <div className="container mx-auto px-6 text-center">
          <h2 className="text-4xl font-display font-bold text-slate-900 mb-6">Ready to join the network?</h2>
          <p className="text-xl text-slate-600 mb-10 max-w-2xl mx-auto">
            Zero financial investment. We're looking for licensed professionals with 1-5 years of experience committed to evidence-based care.
          </p>
          <a href="mailto:hello@theonlinephysio.in" className="btn-primary text-lg px-10 py-4 inline-flex items-center gap-2">
            Contact Us to Discuss <ArrowRight size={20} />
          </a>
        </div>
      </section>
    </div>
  );
};
