import React from 'react';
import { motion } from 'motion/react';
import { Clock, Activity, Video, Users, CheckCircle2, Shield, Mail, Phone, MapPin, Zap, X, Upload } from 'lucide-react';

export const Pricing = () => {
  const plans = [
    { 
      tag: "PR",
      name: "Pre-Consult or Brief Case Review", 
      price: 400, 
      duration: "15 mins", 
      subtitle: "I just have a few questions",
      features: [
        "Pre-consultation screenings, quick medical enquiries or rapid progress updates.",
        "Those who need a quick expert opinion or a steer in the right direction before committing.",
        "Clarifying progress or a short review of your current state."
      ], 
      icon: <Clock /> 
    },
    { 
      tag: "SV",
      name: "Standard Video Consultation", 
      price: 800, 
      duration: "45 mins", 
      subtitle: "I am a new patient",
      features: [
        "Detailed first-time assessments and establishing a new treatment roadmap.",
        "Staying on track with your exercises and discussing your physical progress.",
        "Feature: Self-Reschedule enabled for maximum flexibility."
      ], 
      icon: <Video />, 
      featured: true 
    },
    { 
      tag: "RF",
      name: "Routine Follow-Up", 
      price: 600, 
      duration: "30 mins", 
      subtitle: "I am an existing patient on a rehab track",
      features: [
        "Ongoing rehab cases needing professional supervision.",
        "Routine monitoring and tactical adjustments of your ongoing rehabilitation plan.",
        "Select this for regular follow-ups on your exercise plan. Includes a complimentary 5-min extension."
      ], 
      icon: <Activity /> 
    },
    { 
      tag: "CR",
      name: "Comprehensive Review", 
      price: 1000, 
      duration: "1 hr", 
      subtitle: "I have a complex/long history",
      features: [
        "Complex, chronic or multi-faceted health concerns requiring a deep-dive analysis.",
        "Patients who feel unheard elsewhere or have a long detailed medical history to share.",
        "Bonus: Includes +5 mins extra time at no cost to ensure no question goes unanswered."
      ], 
      icon: <Users /> 
    },
  ];

  const [submitted, setSubmitted] = React.useState(false);
  const [selectedSlots, setSelectedSlots] = React.useState<string[]>(['']);
  const [selectedPlanIndex, setSelectedPlanIndex] = React.useState<number>(1);
  const [loading, setLoading] = React.useState(false);

  const addSlot = () => setSelectedSlots([...selectedSlots, '']);
  const removeSlot = (index: number) => {
    const newSlots = selectedSlots.filter((_, i) => i !== index);
    setSelectedSlots(newSlots.length ? newSlots : ['']);
  };

  const updateSlot = (index: number, value: string) => {
    const newSlots = [...selectedSlots];
    newSlots[index] = value;
    setSelectedSlots(newSlots);
  };

  const calculateTotal = () => {
    const count = selectedSlots.filter(s => s).length;
    const price = plans[selectedPlanIndex].price;
    const total = count * price;
    const discount = count >= 5 ? total * 0.05 : 0;
    return { total, discount, final: total - discount };
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    
    const formData = new FormData(e.target as HTMLFormElement);
    const data = {
      name: `${formData.get('title')} ${formData.get('name')}`,
      phone: formData.get('phone'),
      age: formData.get('age'),
      condition: formData.get('condition'),
      consultedOther: formData.get('consultedOther'),
      referredBy: formData.get('referredBy'),
      plan: plans[selectedPlanIndex].name,
      slots: selectedSlots.filter(s => s),
      ...calculateTotal()
    };

    try {
      const res = await fetch('/api/intake', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data)
      });
      if (res.ok) setSubmitted(true);
    } catch (err) {
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen py-24">
      <div className="container mx-auto px-6">
        <div className="text-center max-w-2xl mx-auto mb-16">
          <span className="text-brand-orange font-bold text-sm tracking-widest uppercase mb-4 block">Appointments</span>
          <h1 className="text-5xl font-display font-black text-slate-900 mb-6 leading-tight">
            Transparent Pricing <br />
            <span className="text-brand-orange">& Booking</span>
          </h1>
          <p className="text-lg text-slate-600 leading-relaxed">
            Simple, affordable plans. No hidden fees. All sessions via secure video call.
          </p>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8 mb-24">
          {plans.map((p, i) => (
            <div 
              key={i} 
              className={`p-8 rounded-3xl border ${p.featured ? 'border-brand-orange bg-brand-orange/5 ring-4 ring-brand-orange/10' : 'border-slate-200 bg-white'} flex flex-col`}
            >
              <div className="flex justify-between items-start mb-6">
                <div className={`p-3 rounded-xl ${p.featured ? 'bg-brand-orange text-white' : 'bg-slate-100 text-slate-500'}`}>
                  {React.cloneElement(p.icon as React.ReactElement, { size: 24 })}
                </div>
                {p.featured && <span className="bg-brand-orange text-white text-[10px] font-black px-2 py-1 rounded-full">POPULAR</span>}
              </div>
              <div className="text-xs font-bold text-brand-orange mb-2">{p.tag} · Online Physio</div>
              <h3 className="text-xl font-bold text-slate-900 mb-1">{p.name}</h3>
              <p className="text-sm text-slate-500 mb-4 h-10">{p.subtitle}</p>
              <div className="flex items-baseline gap-1 mb-6">
                <span className="text-3xl font-black text-slate-900">₹{p.price}</span>
                <span className="text-slate-500 text-sm">/ {p.duration}</span>
              </div>
              <div className="text-sm font-bold text-slate-900 mb-3">Best For:</div>
              <ul className="space-y-3 mb-8 flex-1">
                {p.features.map((f, j) => (
                  <li key={j} className="flex items-start gap-2 text-sm text-slate-600">
                    <CheckCircle2 size={16} className="text-brand-green shrink-0 mt-0.5" /> 
                    <span className="leading-snug">{f}</span>
                  </li>
                ))}
              </ul>
              <button 
                onClick={() => {
                  setSelectedPlanIndex(i);
                  document.getElementById('booking-form')?.scrollIntoView({ behavior: 'smooth' });
                }}
                className={`w-full py-3 rounded-xl font-bold text-center transition-all ${p.featured ? 'bg-brand-orange text-white shadow-lg shadow-brand-orange/20' : 'bg-slate-100 text-slate-600 hover:bg-slate-200'}`}
              >
                Select Plan
              </button>
            </div>
          ))}
        </div>

        <div id="booking-form" className="grid grid-cols-1 lg:grid-cols-2 gap-16 max-w-6xl mx-auto">
          <div>
            <h2 className="text-4xl font-display font-bold text-slate-900 mb-6">Tell Us Where It Hurts</h2>
            <p className="text-slate-600 mb-6 leading-relaxed text-lg">
              Tell us about your injury. Your data is secure and confidential. We'll reach out within 24 hours after reviewing if online physio is a fit.
            </p>
            <div className="p-4 bg-brand-orange/10 border border-brand-orange/20 rounded-xl mb-10">
              <p className="text-sm text-brand-orange font-bold flex items-start gap-2">
                <Shield size={18} className="shrink-0 mt-0.5" />
                Note: For emergencies or severe injuries, please visit a hospital immediately.
              </p>
            </div>
            
            <div className="space-y-6">
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                  <Mail size={20} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Email Us</p>
                  <p className="font-bold text-slate-900">hello@theonlinephysio.in</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                  <Phone size={20} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">WhatsApp</p>
                  <p className="font-bold text-slate-900">+91 99863 70169</p>
                </div>
              </div>
              <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-slate-100 rounded-xl flex items-center justify-center text-slate-600">
                  <MapPin size={20} />
                </div>
                <div>
                  <p className="text-xs font-bold text-slate-400 uppercase tracking-wider">Based In</p>
                  <p className="font-bold text-slate-900">Bengaluru, Karnataka</p>
                </div>
              </div>
            </div>
          </div>
          <div className="bg-white p-8 md:p-10 rounded-3xl shadow-2xl border border-slate-100">
            {submitted ? (
              <div className="text-center py-12">
                <div className="w-20 h-20 bg-brand-green/10 text-brand-green rounded-full flex items-center justify-center mx-auto mb-6">
                  <CheckCircle2 size={40} />
                </div>
                <h3 className="text-2xl font-bold text-slate-900 mb-2">Intake Form Submitted!</h3>
                <p className="text-slate-500">We'll review your case and contact you via WhatsApp within 24 hours.</p>
              </div>
            ) : (
              <form onSubmit={handleSubmit} className="space-y-6">
                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Full Name *</label>
                  <div className="flex gap-3">
                    <select name="title" required className="w-24 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 outline-none">
                      <option value="">Title</option>
                      <option value="Mr.">Mr.</option>
                      <option value="Mrs.">Mrs.</option>
                      <option value="Ms.">Ms.</option>
                      <option value="Dr.">Dr.</option>
                    </select>
                    <input name="name" required type="text" placeholder="Name" className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 outline-none" />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Age *</label>
                    <input name="age" required type="number" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 outline-none" />
                  </div>
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Phone (WhatsApp) *</label>
                    <input name="phone" required type="tel" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 outline-none" />
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">What's bothering you? *</label>
                  <textarea name="condition" required className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 outline-none h-24 resize-none" />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Have you consulted any other doctor? *</label>
                  <div className="flex gap-6">
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="consultedOther" value="Yes" required className="w-4 h-4 text-brand-orange focus:ring-brand-orange" />
                      <span className="text-sm text-slate-700">Yes</span>
                    </label>
                    <label className="flex items-center gap-2 cursor-pointer">
                      <input type="radio" name="consultedOther" value="No" required className="w-4 h-4 text-brand-orange focus:ring-brand-orange" />
                      <span className="text-sm text-slate-700">No</span>
                    </label>
                  </div>
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Who referred you to me?</label>
                  <input name="referredBy" type="text" className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 outline-none" />
                </div>

                <div className="space-y-2">
                  <label className="text-sm font-bold text-slate-700">Would you like to share any scans or reports with us?</label>
                  <div className="relative">
                    <input type="file" className="absolute inset-0 w-full h-full opacity-0 cursor-pointer" />
                    <div className="w-full p-4 border-2 border-dashed border-slate-200 rounded-xl bg-slate-50 flex items-center justify-center gap-2 text-slate-500 hover:border-brand-orange hover:text-brand-orange transition-colors">
                      <Upload size={20} />
                      <span className="text-sm font-bold">Choose File</span>
                    </div>
                  </div>
                </div>

                <div className="pt-6 border-t border-slate-100 space-y-4">
                  <div className="space-y-2">
                    <label className="text-sm font-bold text-slate-700">Select Appointment Type *</label>
                    <select 
                      value={selectedPlanIndex}
                      onChange={(e) => setSelectedPlanIndex(Number(e.target.value))}
                      className="w-full p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 outline-none font-bold text-slate-900"
                    >
                      {plans.map((p, i) => (
                        <option key={i} value={i}>{p.name} (₹{p.price} / {p.duration})</option>
                      ))}
                    </select>
                  </div>

                  <div className="space-y-3">
                    <div className="flex justify-between items-center">
                      <label className="text-sm font-bold text-slate-700">Select Slots *</label>
                      <button type="button" onClick={addSlot} className="text-xs font-bold text-brand-orange hover:underline bg-brand-orange/10 px-3 py-1 rounded-full">+ Add Bulk Slot</button>
                    </div>
                    {selectedSlots.map((slot, index) => (
                      <div key={index} className="flex gap-2">
                        <input 
                          required 
                          type="datetime-local" 
                          value={slot}
                          onChange={(e) => updateSlot(index, e.target.value)}
                          className="flex-1 p-3 bg-slate-50 border border-slate-200 rounded-xl focus:ring-2 focus:ring-brand-orange/20 outline-none" 
                        />
                        {selectedSlots.length > 1 && (
                          <button type="button" onClick={() => removeSlot(index)} className="p-3 text-slate-400 hover:text-red-500 bg-slate-50 border border-slate-200 rounded-xl">
                            <X size={20} />
                          </button>
                        )}
                      </div>
                    ))}
                    {selectedSlots.length >= 5 && (
                      <p className="text-xs font-bold text-brand-green flex items-center gap-1">
                        <CheckCircle2 size={14} /> 5% Bulk Discount Applied!
                      </p>
                    )}
                  </div>
                </div>

                {selectedSlots.filter(s => s).length > 0 && (
                  <div className="p-4 bg-slate-50 rounded-2xl border border-slate-200 space-y-2">
                    <div className="flex justify-between text-sm">
                      <span className="text-slate-500">Subtotal ({selectedSlots.filter(s => s).length} sessions)</span>
                      <span className="font-bold">₹{calculateTotal().total}</span>
                    </div>
                    {calculateTotal().discount > 0 && (
                      <div className="flex justify-between text-sm text-brand-green">
                        <span>Bulk Discount (5%)</span>
                        <span className="font-bold">- ₹{calculateTotal().discount}</span>
                      </div>
                    )}
                    <div className="flex justify-between text-lg font-black pt-2 border-t border-slate-200">
                      <span>Total Payable</span>
                      <span className="text-brand-orange">₹{calculateTotal().final}</span>
                    </div>
                  </div>
                )}

                <div className="space-y-2">
                  <label className="flex items-start gap-3 cursor-pointer group">
                    <input type="checkbox" required className="mt-1 w-4 h-4 text-brand-orange focus:ring-brand-orange rounded border-slate-300" />
                    <span className="text-xs text-slate-500 leading-relaxed group-hover:text-slate-700 transition-colors">
                      <strong className="text-slate-700">Terms and Conditions *</strong><br/>
                      I agree to the Terms. I consent to data processing (DPDP Act) for treatment, understand the limits of remote physio, and confirm I am not in a medical emergency.
                    </span>
                  </label>
                </div>

                <div className="pt-4">
                  <button type="submit" disabled={loading} className="w-full btn-primary py-4 text-lg disabled:opacity-50 shadow-xl shadow-brand-orange/20">
                    {loading ? 'Submitting...' : 'Submit'}
                  </button>
                  <p className="text-[10px] text-center text-slate-400 mt-4 px-4">
                    Do not submit confidential information such as credit card details, mobile and ATM PINs, OTPs, account passwords, etc.
                  </p>
                </div>
              </form>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

