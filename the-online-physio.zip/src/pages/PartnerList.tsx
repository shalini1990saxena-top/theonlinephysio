import React from 'react';
import { motion } from 'motion/react';
import { MapPin, User, ExternalLink, Search } from 'lucide-react';
import { Link } from 'react-router-dom';

interface Partner {
  id: number;
  name: string;
  city: string;
  experience?: number;
}

const MOCK_PARTNERS: Partner[] = [
  { id: 1, name: "Dr. Anjali Sharma", city: "Mysore", experience: 4 },
  { id: 2, name: "Dr. Rahul Verma", city: "Coimbatore", experience: 3 },
  { id: 3, name: "Dr. Sneha Patil", city: "Jaipur", experience: 5 },
  { id: 4, name: "Dr. Vikram Singh", city: "Lucknow", experience: 2 },
];

export const PartnerList = () => {
  const [partners, setPartners] = React.useState<Partner[]>([]);
  const [search, setSearch] = React.useState('');
  const [loading, setLoading] = React.useState(true);

  React.useEffect(() => {
    fetch('/api/partners')
      .then(res => res.json())
      .then(data => {
        if (data.length > 0) {
          setPartners(data);
        } else {
          setPartners(MOCK_PARTNERS);
        }
        setLoading(false);
      })
      .catch(() => {
        setPartners(MOCK_PARTNERS);
        setLoading(false);
      });
  }, []);

  const filtered = partners.filter(p => 
    p.name.toLowerCase().includes(search.toLowerCase()) || 
    p.city.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen py-24 bg-slate-50">
      <div className="container mx-auto px-6">
        <div className="max-w-4xl mx-auto space-y-12">
          <div className="text-center space-y-4">
            <span className="text-brand-green font-bold text-sm tracking-widest uppercase block">Our Network</span>
            <h1 className="text-5xl font-display font-black text-slate-900">Partner Physiotherapists</h1>
            <p className="text-xl text-slate-600 leading-relaxed">
              Find trusted physiotherapy professionals in your city, powered by The Online Physio.
            </p>
          </div>

          <div className="relative max-w-md mx-auto">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 text-slate-400" size={20} />
            <input 
              type="text" 
              placeholder="Search by name or city..." 
              className="w-full pl-12 pr-4 py-4 bg-white border border-slate-200 rounded-2xl shadow-sm focus:ring-2 focus:ring-brand-green/20 focus:border-brand-green outline-none transition-all"
              value={search}
              onChange={e => setSearch(e.target.value)}
            />
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {loading ? (
              <div className="col-span-full text-center py-12 text-slate-400">Loading partners...</div>
            ) : filtered.length === 0 ? (
              <div className="col-span-full text-center py-12 text-slate-400">No partners found in this city yet.</div>
            ) : (
              filtered.map((partner, i) => (
                <motion.div 
                  initial={{ opacity: 0, y: 10 }}
                  animate={{ opacity: 1, y: 0 }}
                  transition={{ delay: i * 0.1 }}
                  key={partner.id} 
                  className="bg-white p-6 rounded-3xl border border-slate-100 shadow-sm hover:shadow-md transition-all flex justify-between items-center"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-14 h-14 bg-brand-green/10 text-brand-green rounded-2xl flex items-center justify-center">
                      <User size={28} />
                    </div>
                    <div>
                      <h3 className="text-lg font-bold text-slate-900">{partner.name}</h3>
                      <div className="flex items-center gap-1 text-slate-500 text-sm">
                        <MapPin size={14} /> {partner.city}
                      </div>
                      {partner.experience && (
                        <p className="text-xs text-slate-400 font-semibold mt-1">{partner.experience} Years Experience</p>
                      )}
                    </div>
                  </div>
                  <Link 
                    to={`/partners/${partner.id}`} 
                    className="p-3 text-brand-green hover:bg-brand-green/10 rounded-xl transition-all"
                    title="View Details"
                  >
                    <ExternalLink size={20} />
                  </Link>
                </motion.div>
              ))
            )}
          </div>

          <div className="bg-brand-orange/5 border border-brand-orange/20 p-8 rounded-3xl text-center">
            <h3 className="text-xl font-bold text-slate-900 mb-2">Are you a physiotherapist?</h3>
            <p className="text-slate-600 mb-6">Join our growing network of professionals across India.</p>
            <Link to="/partner-network" className="btn-primary inline-flex items-center gap-2">
              Learn About Partnership
            </Link>
          </div>
        </div>
      </div>
    </div>
  );
};
